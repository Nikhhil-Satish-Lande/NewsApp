package com.security.newdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
