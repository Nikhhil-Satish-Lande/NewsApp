package com.security.newdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewdemoApplication.class, args);
	}

}
